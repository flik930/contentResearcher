---
agent: workflow.orchestrator
topic: 維他命C精華液功效安全性配搭建議敏感肌
job_id: vitc-sensitive-skin-20250821
timestamp: 2025-08-21T14:20:30Z
workflow_type: Evidence
complexity: complex
estimated_tokens: 28000
estimated_duration: 18
cache_utilization: 0.15
performance_targets:
  token_efficiency: 65%
  quality_threshold: 0.95
  completion_target: 18
---

# 維他命C精華液敏感肌工作流程計劃

## 查詢分析總結

用戶查詢：「維他命C精華液功效、安全性及配搭建議，適合30歲敏感肌使用」

此查詢明確屬於Evidence路徑，涉及：
- 功效驗證（科學證據）
- 安全性評估（敏感肌適用性）
- 配搭建議（成分相容性）
- 特定年齡群組（30歲）
- 特殊肌膚類型（敏感肌）

```yaml
workflow_plan:
  # 元信息
  analysis_summary:
    topic: "維他命C精華液敏感肌應用"
    complexity: "complex"
    workflow_path: "Evidence"
    path_confidence: 0.95
    estimated_duration: "18分鐘"
    estimated_tokens: 28000
  
  # 快取利用評估
  cache_assessment:
    topic_coverage: 0.15
    existing_sources: 7
    research_gaps: 
      - "維他命C在敏感肌的安全性數據"
      - "30歲年齡群組特定需求"
      - "香港氣候下的使用建議"
      - "與其他成分的配搭禁忌"
      - "敏感肌適用的維他命C濃度範圍"
    expected_savings: "15%"
  
  # 執行步驟
  execution_steps:
    - step_id: 1
      action: "profile_analysis"
      agents: ["profiler.angle"]
      execution_mode: "sequential"
      prompt_template: |
        分析目標用戶檔案：30歲敏感肌女性對維他命C精華液的需求

        關鍵分析要點：
        1. 30歲肌膚生理特徵與需求
        2. 敏感肌膚的護膚品選擇限制
        3. 維他命C對此年齡群組的優先效益
        4. 香港環境因素（濕度、污染、紫外線）
        5. 生活方式考慮（工作壓力、作息）

        輸出用戶檔案摘要，為後續研究提供精準定向。
      expected_outputs: ["用戶檔案摘要", "需求優先級排序", "安全性關注點"]
      token_budget: 3000
      
    - step_id: 2
      action: "parallel_research"
      agents: ["evidence.safe-001", "evidence.safe-002", "evidence.safe-003"]
      execution_mode: "parallel"
      assignments:
        evidence.safe-001:
          focus_clusters: ["維他命C功效機制", "抗氧化科學證據", "膠原蛋白合成"]
          cache_baseline: 0.20
          new_sources_target: 15
          token_budget: 8000
          prompt_template: |
            深度研究維他命C精華液的科學功效，特別針對30歲肌膚需求：

            優先研究領域：
            1. 維他命C的抗氧化機制（分子層面）
            2. 膠原蛋白合成促進（30歲後流失加速）
            3. 色素沉澱改善（香港陽光曝曬）
            4. 細紋預防與改善
            5. 肌膚屏障修復

            研究要求：
            - 引用最新5年內同行評議文獻
            - 包含隨機對照試驗數據
            - 注重亞洲人群研究
            - GRADE證據等級評估
            - 量化效果數據
        
        evidence.safe-002:
          focus_clusters: ["敏感肌安全性", "維他命C刺激性", "濃度安全範圍"]
          cache_baseline: 0.10
          new_sources_target: 12
          token_budget: 7000
          prompt_template: |
            專項研究維他命C在敏感肌使用的安全性：

            核心研究重點：
            1. 敏感肌膚的維他命C耐受性
            2. 不同濃度的刺激風險評估
            3. 維他命C衍生物的溫和性比較
            4. 過敏反應案例分析
            5. 安全使用指引

            特別關注：
            - 敏感肌專用臨床試驗
            - 亞洲敏感肌數據
            - 皮膚科醫師建議
            - 不良反應發生率
            - 安全濃度閾值
        
        evidence.safe-003:
          focus_clusters: ["成分配搭", "產品推薦", "使用方法"]
          cache_baseline: 0.05
          new_sources_target: 10
          token_budget: 6000
          prompt_template: |
            研究維他命C精華液的配搭建議和最佳使用方案：

            研究範疇：
            1. 與其他活性成分的相容性
            2. 配搭禁忌（煙醯胺、果酸、A醇等）
            3. 使用時間建議（早/晚）
            4. 香港市場產品評估
            5. 30歲敏感肌適用產品篩選

            實用性重點：
            - 具體產品推薦理由
            - 使用順序指引
            - 香港購買渠道
            - 價格效益分析
            - 季節使用調整
      
      quality_requirements:
        min_grade_compliance: 0.95
        geographic_diversity: required
        citation_completeness: 100%
    
    - step_id: 3
      action: "research_synthesis"
      agents: ["research.synthesizer"]
      execution_mode: "sequential"
      input_dependencies: ["step_2_outputs"]
      prompt_template: |
        綜合三個研究組的發現，建構完整的維他命C敏感肌使用指南：

        整合任務：
        1. 功效證據整理與等級評定
        2. 安全性數據統一評估
        3. 配搭建議系統化整理
        4. 衝突信息解決與平衡
        5. 實用建議優先級排序

        輸出要求：
        - 證據強度分級
        - 安全性評分系統
        - 具體使用方案
        - 風險提示清單
        - 產品選擇指引
      token_budget: 4000
    
    - step_id: 4
      action: "strategy_mapping"
      agents: ["strategy.mapper"]
      execution_mode: "sequential"
      input_dependencies: ["step_3_outputs"]
      prompt_template: |
        將研究證據轉化為30歲敏感肌用戶的實用策略：

        策略制定重點：
        1. 循序漸進的使用計劃
        2. 風險最小化策略
        3. 效果最大化方案
        4. 香港環境適應性調整
        5. 預算考量與性價比選擇

        實用策略包含：
        - 新手入門指引
        - 進階使用方案
        - 問題解決對策
        - 季節性調整
        - 產品升級路徑
      token_budget: 3500
    
    - step_id: 5
      action: "content_presentation"
      agents: ["editor.presenter"]
      execution_mode: "sequential"
      input_dependencies: ["step_4_outputs"]
      prompt_template: |
        製作香港本地化的維他命C精華液內容，針對30歲敏感肌用戶：

        內容規格：
        - 社交媒體版本（精華重點）
        - 文章版本（詳細指南）
        - 深度指南版本（完整參考）

        本地化要素：
        - 香港氣候考量
        - 本地購買渠道
        - 粵語表達習慣
        - HKStylist軟性植入
        - 港式生活場景

        品質要求：
        - 專業權威感
        - 親和易懂
        - 實用可操作
        - 安全性優先
        - 證據支撐充分
      personas_count: 1
      content_tiers: ["social", "article", "guide"]
      token_budget: 4500
  
  # 監控和優化
  success_criteria:
    quality_threshold: 0.95
    completion_rate: 100%
    token_efficiency: ">65% vs 無快取基準"
    
  fallback_plans:
    if_agent_fails: "使用單一evidence.safe-001補充研究"
    if_quality_low: "觸發額外安全性驗證輪次"
    if_token_exceeded: "優先保留安全性和配搭建議，精簡功效描述"
  
  # 性能追蹤
  expected_performance:
    token_reduction_vs_baseline: "35%"
    time_savings_vs_baseline: "25%"
    cache_hit_rate: 0.15
    research_overlap_elimination: ">70%"
```

## 執行優化策略

### 高複雜度Evidence查詢優化
此查詢涉及多個專業領域（功效、安全性、配搭），採用parallel_research策略最大化研究效率：

1. **三線並行研究**：功效、安全性、實用建議分別深入
2. **快取利用**：基於現有透明質酸研究進行類比擴展
3. **本地化重點**：香港氣候、購買渠道、粵語表達
4. **安全性優先**：敏感肌用戶的風險最小化

### 質量保證機制
- **GRADE方法學**：所有證據必須達到95%合規
- **多層驗證**：research.synthesizer進行衝突解決
- **實用性檢驗**：strategy.mapper確保建議可操作性
- **本地化審核**：editor.presenter進行香港化適配

### 資源分配邏輯
- **總預算28,000 tokens**：基於複雜度和低快取覆蓋率
- **並行研究60%**：三個evidence.safe同時作業提升效率
- **合成與策略25%**：深度整合避免信息碎片化
- **內容製作15%**：三層級內容滿足不同需求

此工作流程預計18分鐘完成，相比傳統單線研究節省25%時間，同時維持95%以上的專業質量標準。