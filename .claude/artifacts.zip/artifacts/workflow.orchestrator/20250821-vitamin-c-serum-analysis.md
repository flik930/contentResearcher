# 維他命C精華液配搭研究 - 工作流程分析

## 查詢分析

**用戶查詢類型**: Evidence + Trend 混合路徑
**複雜度**: 高 (涉及成分相容性、安全性、產品評估)
**目標用戶**: 30歲敏感肌職場女性，月預算HK$300-800

## 執行計劃

### Phase 1: 用戶檔案分析 (Sequential)
**負責Agent**: profiler.angle
**目標**: 深度分析30歲敏感肌用戶需求
**Token預算**: 1,500

### Phase 2: 並行證據研究 (Parallel)
**負責Agents**: evidence.safe-001, evidence.safe-002
**研究分工**:
- evidence.safe-001: 維他命C成分相容性、配搭禁忌
- evidence.safe-002: 敏感肌安全性、使用時間建議

**Token預算**: 各3,000

### Phase 3: 香港市場趨勢分析 (Sequential)  
**負責Agent**: trend.harvest
**目標**: 香港市場產品評估、購買渠道、價格效益
**Token預算**: 2,500

### Phase 4: 整合與策略制定 (Sequential)
**負責Agent**: strategy.mapper
**目標**: 整合研究結果，制定實用配搭方案
**Token預算**: 2,000

### Phase 5: 內容創建 (Sequential)
**負責Agent**: editor.presenter  
**目標**: 創建港式專業美容指南
**Token預算**: 2,500

## 質量檢查點
- GRADE methodology compliance >95%
- 敏感肌安全性驗證
- 香港本地化驗證
- 預算範圍符合度檢查

## 預期產出
- 完整維他命C精華液使用指南
- 產品推薦清單 (HK$300-800範圍)
- 配搭禁忌與建議時間表
- 香港購買渠道指南