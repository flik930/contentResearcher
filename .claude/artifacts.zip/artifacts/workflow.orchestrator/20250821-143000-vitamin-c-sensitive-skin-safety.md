---
agent: workflow.orchestrator
topic: 維他命C敏感肌安全性評估
job_id: vc_sensitive_2025082114
timestamp: 2025-08-21T14:30:00Z
workflow_type: Evidence
complexity: complex
estimated_tokens: 35000
estimated_duration: 18分鐘
cache_utilization: 0.05
performance_targets:
  token_efficiency: 65%
  quality_threshold: 0.95
  completion_target: 20分鐘
---

# 維他命C敏感肌安全性評估 - 智能工作流程計劃

## 查詢分析結果

**核心議題**: 維他命C在敏感肌膚使用的安全性和耐受性
**複雜度評級**: Complex（高度專業的醫學美容安全評估）
**建議工作流程路徑**: Evidence Path（科學證據導向）
**路徑信心度**: 0.95

### 關鍵研究領域識別
1. 敏感肌膚對維他命C的生理反應機制
2. 不同濃度梯度的刺激風險評估（1%, 5%, 10%, 15%, 20%+）
3. 維他命C衍生物溫和性比較（MAP, SAP, 鎂鹽等）
4. 亞洲敏感肌特殊考慮因素
5. 臨床過敏反應案例統計與預防指引

## 快取覆蓋評估

```yaml
cache_assessment:
  topic_coverage: 0.05  # 維他命C敏感肌專項研究在快取中覆蓋度極低
  existing_sources: 0
  research_gaps: 
    - "敏感肌維他命C耐受性臨床試驗"
    - "亞洲敏感肌膚維他命C反應數據"
    - "維他命C衍生物安全性比較研究"
    - "敏感肌維他命C使用指引皮膚科consensus"
    - "香港氣候環境下維他命C敏感肌使用注意事項"
  expected_savings: 5%  # 幾乎需要全新研究
```

**快取狀況**: 幾乎無相關快取數據，需要進行全面的專項研究

## 工作流程執行計劃

```yaml
execution_steps:
  - step_id: 1
    action: "sensitive_skin_profile_analysis"
    agents: ["profiler.angle"]
    execution_mode: "sequential"
    prompt_template: |
      分析敏感肌用戶的維他命C使用安全考慮：
      
      目標用戶：30歲香港職場女性，敏感肌歷史，極度重視安全性
      
      請提供：
      1. 敏感肌膚特徵和維他命C反應風險評估
      2. 香港濕熱氣候對敏感肌使用維他命C的影響
      3. 職場壓力和生活方式對皮膚耐受性的影響
      4. 個人化安全使用建議框架
      
      重點考慮：安全性>功效性，循序漸進使用策略
    expected_outputs: ["敏感肌用戶profile", "風險評估框架", "個人化使用指引"]
    token_budget: 4000

  - step_id: 2
    action: "comprehensive_safety_research"
    agents: ["evidence.safe-001", "evidence.safe-002", "evidence.safe-003"]
    execution_mode: "parallel"
    assignments:
      evidence.safe-001:
        focus_clusters: ["敏感肌維他命C耐受性", "臨床安全性試驗"]
        cache_baseline: 0.00
        new_sources_target: 15
        token_budget: 12000
        prompt_template: |
          專項研究：維他命C在敏感肌使用的安全性證據
          
          研究重點：
          - 敏感肌膚對維他命C的生理耐受性機制
          - 不同濃度(1%-20%)在敏感肌的刺激風險
          - 敏感肌專用維他命C產品臨床試驗
          - 過敏反應發生率統計數據
          
          優先尋找：
          - Cochrane系統性回顧
          - 皮膚科期刊RCT研究
          - FDA/EMA安全性評估
          - 亞洲皮膚科醫學會指引
          
          輸出格式：按GRADE方法論評估每項證據
          
      evidence.safe-002:
        focus_clusters: ["維他命C衍生物安全性", "溫和性比較"]
        cache_baseline: 0.00
        new_sources_target: 12
        token_budget: 10000
        prompt_template: |
          專項研究：維他命C衍生物在敏感肌的安全性比較
          
          研究重點：
          - MAP (鎂鹽) vs SAP (鈉鹽) vs 左旋維他命C 安全性
          - 衍生物的刺激性和效果平衡
          - 敏感肌適用的維他命C形式推薦
          - 配方pH值對敏感肌刺激性影響
          
          特別關注：
          - 日韓敏感肌產品研究
          - 亞洲敏感肌臨床數據
          - 皮膚科醫師處方習慣
          
          輸出標準：證據強度分級，安全性排序
          
      evidence.safe-003:
        focus_clusters: ["過敏反應案例", "使用指引consensus"]
        cache_baseline: 0.00  
        new_sources_target: 10
        token_budget: 8000
        prompt_template: |
          專項研究：維他命C敏感肌使用的實務指引和風險管理
          
          研究重點：
          - 維他命C過敏反應案例分析
          - 皮膚科醫師使用建議consensus
          - 安全濃度閾值和漸進使用法
          - 與其他成分併用的交互作用風險
          
          重點收集：
          - 香港皮膚科醫學會建議
          - 亞太區皮膚科專家意見
          - 敏感肌護膚品牌研發數據
          - 消費者安全使用經驗調研
          
          輸出要求：實用安全指引，風險分級系統
          
    quality_requirements:
      min_grade_compliance: 0.95
      geographic_diversity: required
      citation_completeness: 100%
      asian_research_priority: high

  - step_id: 3
    action: "safety_research_synthesis"
    agents: ["research.synthesizer"]
    execution_mode: "sequential"
    input_dependencies: ["step_2_outputs"]
    prompt_template: |
      整合維他命C敏感肌安全性的多重研究發現：
      
      任務：
      1. 統整三個研究面向的發現
      2. 建立敏感肌維他命C安全性等級系統
      3. 整理最佳實務使用指引
      4. 識別研究空缺和注意事項
      
      輸出格式：
      - 執行摘要：安全性結論
      - 證據強度評估表
      - 分級使用建議
      - 風險提醒清單
      
      特別要求：以香港敏感肌用戶角度整理實用建議
    token_budget: 6000

  - step_id: 4  
    action: "safety_strategy_mapping"
    agents: ["strategy.mapper"]
    execution_mode: "sequential"
    input_dependencies: ["step_3_outputs"]
    prompt_template: |
      將維他命C敏感肌安全研究轉化為實用策略建議：
      
      策略目標：
      1. 為30歲香港敏感肌職場女性設計安全使用策略
      2. 建立個人化的維他命C使用評估流程
      3. 提供產品選擇和使用指引
      4. 設計風險監控和應對機制
      
      考慮因素：
      - 香港濕熱氣候影響
      - 職場生活壓力
      - 敏感肌歷史和耐受性
      - 循序漸進的安全使用方案
      
      輸出內容：分階段安全使用計劃，緊急應對措施
    token_budget: 5000

  - step_id: 5
    action: "safety_guide_presentation"
    agents: ["editor.presenter"]
    execution_mode: "sequential"
    input_dependencies: ["step_4_outputs"]
    prompt_template: |
      製作維他命C敏感肌安全使用指南：
      
      目標受眾：30歲香港敏感肌職場女性
      內容層次：
      1. Social媒體版：安全要點精華 (300字)
      2. Article版：全面安全指南 (1500字)
      3. Guide版：詳細使用手冊 (3000字)
      
      風格要求：
      - 傳統中文(香港)，友善專業語調
      - 強調安全性和謹慎使用
      - 提供實際可操作的建議
      - 包含HKStylist平台相關stylists推薦
      
      必須包含：風險警告，緊急處理，專業諮詢建議
    personas_count: 1
    content_tiers: ["social", "article", "guide"]  
    token_budget: 8000
```

## 成功標準

```yaml
success_criteria:
  quality_threshold: 0.95
  completion_rate: 100%
  token_efficiency: ">65% vs baseline"
  evidence_sources: ">35個高質量來源"
  safety_coverage: "涵蓋所有關鍵風險點"
  
fallback_plans:
  if_agent_fails: "調用backup evidence.safe agent"
  if_quality_low: "啟動補充研究，專注高等級證據"
  if_token_exceeded: "優先保留核心安全建議，精簡輔助內容"
```

## 預期效能

```yaml
expected_performance:
  token_reduction_vs_baseline: "65%" 
  time_savings_vs_baseline: "40%"
  cache_hit_rate: 0.05
  research_overlap_elimination: ">80%"
  safety_compliance: "100%"
  
quality_assurance:
  medical_accuracy: "皮膚科專業標準"
  evidence_grading: "GRADE methodology"
  cultural_appropriateness: "香港在地化程度>90%"
```

## 備註

此次查詢為高風險醫學美容安全評估，將採用最嚴格的證據標準和全面的安全性研究。由於快取中缺乏相關專項研究，需要進行comprehensive research approach，預計投入較多資源以確保研究品質和安全建議的準確性。

**優先級**: 安全性 > 功效性 > 成本效率
**品質要求**: 醫療級證據標準，100%引用完整性